pool=(bicycle.png satellite.png tool_kit.png)
num=${#pool[*]}
result=${pool[$((RANDOM%num))]}
rm logo.png
ln -s "$result" logo.png

